import tkinter as tk

def Score_window(scoreWindow, master):

    def close_window():
        # on détruit la 3e et la 2e fenêtre
        scoreWindow.destroy()
        master.destroy()

    # taille de la fenêtre
    scoreWindow.geometry( "300x200" )
    scoreWindow.config( background="lightblue" )

    tk.Label(scoreWindow, text="table des scores").pack()
    tk.Label(scoreWindow, text="...").pack()
    quitButton = tk.Button(scoreWindow, text = 'Quit', width = 25, command = close_window)
    quitButton.pack()


