import tkinter as tk
import login_window as lw

# on lance la 1e fenêtre
root = tk.Tk()
app = lw.Login_window(root)
root.mainloop()

