import tkinter as tk
import game_window as gw

# 1ère fenêtre se remplit ici 
def Login_window(master):
    
    def open_game_window():
        # on lance la 2e fenêtre
        # avec passage d'arguments 
        game_window = tk.Toplevel(master)
        # on récupère le login entré par l'utilisateur
        user_name = login_e.get()
        app = gw.Game_window(game_window, user_name )

    # taille de la fenêtre
    master.geometry( "600x400" )
    master.config( background="lightgreen" )

    # créer une "entry" càd un emplacement pour saisir une donnée sur une ligne
    tk.Label(master, text="votre login").pack()
    login_e = tk.Entry(master)
    login_e.pack() # affichage
    login_e.focus_set() # mettre le curseur de la souris dans cet entry

    # bouton à cliquer pour lancer la 2e fenêtre
    button1 = tk.Button(master, text = 'Open Game Window', width = 25, command = open_game_window)
    button1.pack()

