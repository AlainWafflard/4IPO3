import tkinter as tk
import score_windows as sw

# 2ème fenêtre se remplit ici 
def Game_window(master, user_name):
    
    def close_window():
        # on détruit cette fenêtre-ci
        master.destroy()

    def score_window():
        # on lance la 3e fenêtre
        # on passe les deux fenêtres en argument car score_window va les détruire 
        scoreWindow = tk.Toplevel(master)
        app = sw.Score_window(scoreWindow, master )
        
    # taille de la fenêtre
    master.geometry( "800x300" )
    master.config( background="yellow" )
    
    # on imprime le nom de l'utilisateur
    print( "Utilisateur : " + user_name )

    tk.Label(master, text="JEU" ).pack()
    tk.Label(master, text="votre login est :{}".format(user_name) ).pack()
    quitButton = tk.Button(master, text = 'Quit', width = 25, command = close_window)
    quitButton.pack()
    scoreButton = tk.Button(master, text = 'SCORES', width = 25, command = score_window)
    scoreButton.pack()
    
